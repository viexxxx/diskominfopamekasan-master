<?php
try {
    $context = stream_context_create([
        'http' => ['timeout' => 5]
    ]);


    $selected_city = isset($_GET['kode_kab_kota']) ? $_GET['kode_kab_kota'] : '3528';

    // Ambil data terbaru dari `get_data.php`
    $data_json = file_get_contents("http://diskominfopamekasan.test/api/get_average_data_kab.php?kode_kab_kota=" . $selected_city);
    $data = json_decode($data_json, true);

    if (!$data_json) {
        throw new Exception("Gagal mengambil data dari API");
    }

    if (!$data || isset($data['error'])) {
        throw new Exception("Data tidak tersedia");
    }
} catch (Exception $e) {
    exit;
}
?>
<?php foreach($data as $info): ?>
    <tr>
        <td><?= $info['variant']?></td>
        <td><?= number_format($info["harga"], 0, ',', '.') . '/kg'?></td>
    </tr>
<?php endforeach; ?>    





