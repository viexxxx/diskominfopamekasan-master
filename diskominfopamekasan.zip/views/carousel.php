<?php
try {
    $context = stream_context_create([
        'http' => ['timeout' => 5]
    ]);
    $selected_city = isset($_GET['kode_kab_kota']) ? $_GET['kode_kab_kota'] : '3528';

    // Ambil data terbaru dari `get_data.php`
    $data_json = file_get_contents("http://diskominfopamekasan.test/api/get_data.php?kode_kab_kota=" . $selected_city);
    $data = json_decode($data_json, true);

    if (!$data_json) {
        throw new Exception("Gagal mengambil data dari API");
    }

    if (!$data || isset($data['error'])) {
        throw new Exception("Data tidak tersedia");
    }
} catch (Exception $e) {
    exit;
}
?>

<div class="price-container">
    <div class="row gx-3 gy-3">
        <?php foreach ($data as $info): ?>
            <?php 
                $chart_id = "chart-" . md5($info["variant"]);
                $color = ($info["status"] === "naik") ? "red" : "green"; 
            ?>
            <div class="col-lg-4 col-md-6 col-sm-12" 
                 x-show="selectedCategory === 'all' || selectedCategory === '<?= $info['variant'] ?>'" 
                 x-transition>
                <div class="price-card">
                    <div class="card-left">
                        <img src="./assets/images/card/ayam.png" alt="<?= $info["variant"] ?>">
                        <span class="price-change <?= ($info["status"] === "naik") ? 'red' : 'green' ?>">
                            <i class="lni <?= ($info["status"] === "naik") ? 'lni lni-arrow-angular-top-left' : 'lni lni-arrow-angular-top-right rotated' ?>"></i>
                            <?= $info["status"] === "naik" ? "+" : "-" ?><?= $info["persen"] ?> | Rp<?= number_format($info["jumlah"], 0, ',', '.') ?>
                        </span>
                    </div>
                    <div class="card-right">
                        <h4><?= $info["variant"] ?></h4>
                        <p>Rp<?= number_format(end($info["harga"]), 0, ',', '.') ?> / kg</p>
                        <div class="graph">
                            <canvas id="<?= $chart_id ?>" class="chart" 
                                data-harga='<?= json_encode($info["harga"]) ?>' 
                                data-tanggal='<?= json_encode($info["date"]) ?>' 
                                data-color="<?= $color ?>">
                            </canvas>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

