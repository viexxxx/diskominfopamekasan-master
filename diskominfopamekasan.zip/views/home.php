<!DOCTYPE html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Diskominfo Pamekasan</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.svg" />

    <!-- ========================= CSS here ========================= -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/animate.css" />
    <link rel="stylesheet" href="assets/css/tiny-slider.css" />
    <link rel="stylesheet" href="assets/css/glightbox.min.css" />
    <link rel="stylesheet" href="assets/css/change.css" />

    <link rel="stylesheet" href="./node_modules/lineicons/assets/icon-fonts/lineicons.css" />


</head>

<body>
    <!--[if lte IE 9]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="https://browsehappy.com/">upgrade your browser</a> to improve
        your experience and security.
      </p>
    <![endif]-->

    <!-- Preloader -->
    <div class="preloader">
        <div class="preloader-inner">
            <div class="preloader-icon">
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
    <!-- /End Preloader -->

    <!-- Start Header Area -->
    <header class="header navbar-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <div class="nav-inner">
                        <!-- Start Navbar -->
                        <nav class="navbar navbar-expand-lg">
                            <a class="navbar-brand" href="index.html">
                                <img src="assets/images/logo/diskominfo.svg" alt="Logo">
                            </a>
                            <button class="navbar-toggler mobile-menu-btn" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul id="nav" class="navbar-nav ms-auto">
                                    <li class="nav-item">
                                        <div class="nav-link">
                                          <a href="?page=home" class="active" aria-label="Toggle navigation">
                                            <span class="icon">
                                                <i class="lni lni-home-2"></i>
                                            </span>
                                            Dashboard
                                          </a>
                                        </div>
                                    </li>
                                      
                                    <li class="nav-item">
                                        <div class="nav-link">
                                          <a href="?page=profile" class="active" aria-label="Toggle navigation">
                                            <span class="icon">
                                                <i class="lni lni-double-quotes-end-1"></i>
                                            </span>
                                            Profil
                                          </a>
                                        </div>
                                    </li>

                                    <li class="nav-item">
                                        <div class="nav-link">
                                          <a href="?page=login" class="active" aria-label="Toggle navigation">
                                            <span class="icon">
                                              <i class="lni lni-exit"></i>
                                            </span>
                                            Login
                                          </a>
                                        </div>
                                    </li>
                                </ul>
                            </div> <!-- navbar collapse -->
                            <div class="button home-btn">
                                <a href="#" class="btn">Contact Us</a>
                            </div>
                        </nav>
                        <!-- End Navbar -->
                    </div>
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </header>
    <!-- End Header Area -->

    <!-- Start Hero Area -->
    <section class="hero-area">
        <div class="container">
          <div class="hero-content">
            <div class="row align-items-center">
              <div class="col-lg-5 col-md-12 col-12">
                <h1>
                  Dashboard <span class="highlight">Pangan</span><br />
                  Kabupaten Pamekasan
                </h1>
              </div>
            </div>
            <div class="search-container">
              <div class="row align-items-center">
                <div class="col-lg-6 col-md-12 col-12">
                  <div class="search-box">
                    <div class="search-input">
                      <input type="text" placeholder="Cari Komoditas" aria-label="Cari Komoditas" />
                      <button class="btn search-btn">
                        <i class="lni lni-search-2"></i>
                      </button>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="search-box">
                      <div class="row">
                        <div class="col-md-3 col-6">
                          <label for="city">Kota/Kabupaten</label>
                          <div class="dropdown-wrapper">
                            <select id="city" class="form-select">
                              <option selected>Kota/Kabupaten</option>
                              <option value="3528">Kab. Pamekasan</option>
                              <option value="3526">Kab. Bangkalan</option>
                              <option value="3527">Kab. Sampang</option>
                              <option value="3529">Kab. Sumenep</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-3 col-6">
                          <label for="price-change">Perubahan Harga</label>
                          <div class="dropdown-wrapper">
                            <select id="price-change" class="form-select">
                              <option selected>Perubahan Harga</option>
                              <option value="1">Harga Naik</option>
                              <option value="2">Harga Turun</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>                  
              </div>
            </div>
            <div class="price-info" x-data="{ selectedCategory: 'all' }" >
                <!-- Row Pertama -->
                <div class="row mb-4">
                    <div class="col-lg-6 col-md-12">
                        <h2 class="section-title">Kategori</h2>
                    </div>
                    <div class="col-lg-6 col-md-12 text-end">
                        <div class="filter-carousel">
                            <div class="filter-buttons-container">
                            <div class="filter-buttons">
                                <button @click="selectedCategory = 'all'" :class="{ 'active' : selectedCategory === 'all' }" class="btn btn-filter">Semua</button>
                                <button @click="selectedCategory = 'Beras Medium'" :class="{ 'active' : selectedCategory === 'Beras Medium' }" class="btn btn-filter">Beras Medium</button>
                                <button @click="selectedCategory = 'Beras Premium'" :class="{ 'active' : selectedCategory === 'Beras Premium' }" class="btn btn-filter">Beras Premium</button>
                                <button @click="selectedCategory = 'Cabai Merah Besar'" :class="{ 'active' : selectedCategory === 'Cabai Merah Besar' }" class="btn btn-filter">Cabai Merah Besar</button>
                                <button @click="selectedCategory = 'Cabai Rawit Merah'" :class="{ 'active' : selectedCategory === 'Cabai Rawit Merah' }" class="btn btn-filter">Cabai Rawit Merah</button>
                                <button @click="selectedCategory = 'Minyak Goreng Sawit Kemasan Premium'" :class="{ 'active' : selectedCategory === 'Minyak Goreng Sawit Kemasan Premium' }" class="btn btn-filter">Minyak Goreng Sawit Kemasan Premium</button>
                                <button @click="selectedCategory = 'Minyakita'" :class="{ 'active' : selectedCategory === 'Minyakita' }" class="btn btn-filter">Minyakita</button>
                                <button @click="selectedCategory = 'Tepung Terigu'" :class="{ 'active' : selectedCategory === 'Tepung Terigu' }" class="btn btn-filter">Tepung Terigu</button>
                                <button @click="selectedCategory = 'Daging Ayam Ras'" :class="{ 'active' : selectedCategory === 'Daging Ayam Ras' }" class="btn btn-filter">Daging Ayam Ras</button>
                                <button @click="selectedCategory = 'Telur Ayam Ras'" :class="{ 'active' : selectedCategory === 'Telur Ayam Ras' }" class="btn btn-filter">Telur Ayam Ras</button>
                                <button @click="selectedCategory = 'Daging Sapi Paha Belakang'" :class="{ 'active' : selectedCategory === 'Daging Sapi Paha Belakang' }" class="btn btn-filter">Daging Sapi Paha Belakang</button>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div x-data>
                    <?php include 'views/carousel.php'; ?>
                </div>

            </div>

            <div class="price-section">
                <div class="row">
                    <!-- Kolom 1 -->
                    <div class="col-lg-6 col-md-12">
                        <h3 class="table-title">Harga Rata-Rata<br><span class="highlight">Harian Nasional</span></h3>
                        <div class="custom-table-wrapper">
                            <table class="custom-table">
                                <thead>
                                    <tr>
                                        <th>Komoditas</th>
                                        <th>Harga</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php include 'views/average.php'; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
    
                    <!-- Kolom 2 -->
                    <div class="col-lg-6 col-md-12">
                        <h3 class="table-title">Harga Rata-Rata<br><span class="highlight">Harian Madura</span></h3>
                        <div class="custom-table-wrapper">
                            <table class="custom-table">
                                <thead>
                                    <tr>
                                        <th>Komoditas</th>
                                        <th>Harga</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php include 'views/average_kab.php'; ?>                                                                                                                                                                                                                                                                            
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>            

            <div class="chart-section">
                <div class="chart-container">
                  <div class="chart-header">
                    <h2>Rp 1.611.751.507 <span class="change green">▲ 139,68%</span></h2>
                    <button class="info-btn"><i class="lni lni-question-circle"></i></button>
                  </div>
                  <canvas id="priceChart"></canvas>
                  <div class="chart-footer">
                    <div class="time-range">
                      <button class="btn-time-range">24 JAM</button>
                      <button class="btn-time-range">1 MGG</button>
                      <button class="btn-time-range">1M</button>
                      <button class="btn-time-range active">1 THN</button>
                      <button class="btn-time-range">SEMUA</button>
                    </div>
                  </div>
                </div>
            </div>

          </div>
        </div>
    </section>
    <!-- End Hero Area -->

    <!-- ========================= scroll-top ========================= -->
    <a href="#" class="scroll-top">
        <i class="lni lni-chevron-up"></i>
    </a>

    <!-- ========================= JS here ========================= -->
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/tiny-slider.js"></script>
    <script src="assets/js/glightbox.min.js"></script>
    <script src="assets/js/count-up.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="./node_modules/chart.js/dist/chart.umd.js"></script>
    <script src="./node_modules/jquery/dist/jquery.js"></script>
    <script src="./node_modules/alpinejs/dist/cdn.js"></script>
    <script>
        const ctx = document.getElementById('priceChart').getContext('2d');

        const priceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], // Data bulan
            datasets: [
            {
                label: 'Harga Kabupaten',
                data: [618649475, 650000000, 670000000, 680000000, 710000000, 750000000, 800000000, 850000000, 900000000, 1000000000, 1300000000, 1611751507], // Data dummy
                borderColor: '#FFA726',
                backgroundColor: 'rgba(255, 167, 38, 0.2)',
                borderWidth: 2,
                pointRadius: 0,
                fill: true,
            },
            {
                label: 'Harga Nasional',
                data: [600000000, 630000000, 660000000, 670000000, 700000000, 720000000, 740000000, 800000000, 850000000, 900000000, 1200000000, 1712254795], // Data dummy
                borderColor: '#000',
                backgroundColor: 'rgba(0, 0, 0, 0.2)',
                borderWidth: 2,
                pointRadius: 0,
                fill: true,
            },
            ],
        },
        options: {
            responsive: true,
            plugins: {
            legend: {
                display: true,
                position: 'bottom',
            },
            },
            scales: {
            x: {
                grid: {
                display: false,
                },
            },
            y: {
                beginAtZero: false,
                ticks: {
                callback: (value) => `Rp${value.toLocaleString()}`, // Format rupiah
                },
            },
            },
        },
        });        
    </script>
    <script>
        $(document).ready(function () {
            window.charts = {}; // Menyimpan semua grafik yang sudah dibuat

            function updateCarousel(city = "3528") {
                let apiUrl = "views/carousel.php";
                let requestData = { kode_kab_kota: city, t: new Date().getTime() }; // Default request untuk kota

                // 🔹 Jika "Rata-Rata Kabupaten" dipilih, ganti URL ke average_kab.php
                if (city === "average") {
                    apiUrl = "views/average_kab.php";
                    requestData = { t: new Date().getTime() }; // Hindari cache
                }

                $.ajax({
                    url: apiUrl,
                    type: "GET",
                    data: requestData,
                    beforeSend: function () {
                        $(".price-carousel").html("<p>Sedang memuat data...</p>");
                    },
                    success: function (response) {
                        $(".price-carousel").html(response); // Update isi carousel

                        // 🔹 Hapus semua grafik lama sebelum mengganti data baru
                        Object.keys(window.charts).forEach(function (chartId) {
                            if (window.charts[chartId]) {
                                window.charts[chartId].destroy(); // Hapus grafik lama
                            }
                        });

                        // 🔹 Render ulang Chart.js setelah carousel diperbarui
                        setTimeout(() => {
                            initializeCharts();
                        }, 300);
                    },
                    error: function (xhr, status, error) {
                        $(".price-carousel").html("<p>Gagal memuat data. Coba lagi.</p>");
                    }
                });
            }

            // 🔹 Fungsi untuk inisialisasi ulang Chart.js
            function initializeCharts() {
                $(".chart").each(function () {
                    var chartId = $(this).attr("id");
                    var hargaData = JSON.parse($(this).attr("data-harga"));
                    var tanggalData = JSON.parse($(this).attr("data-tanggal"));
                    var borderColor = $(this).attr("data-color");

                    var ctx = document.getElementById(chartId).getContext("2d");

                    window.charts[chartId] = new Chart(ctx, {
                        type: "line",
                        data: {
                            labels: tanggalData,
                            datasets: [{
                                data: hargaData,
                                borderColor: borderColor,
                                borderWidth: 2,
                                pointRadius: 4,
                                pointBackgroundColor: borderColor,
                                fill: false,
                                tension: 0.3
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                x: {
                                    ticks: {
                                        font: { size: 10 },
                                        autoSkip: false
                                    }
                                },
                                y: {
                                    beginAtZero: false,
                                    ticks: {
                                        font: { size: 10 },
                                        callback: function(value) {
                                            return "Rp" + value.toLocaleString("id-ID");
                                        }
                                    }
                                }
                            },
                            plugins: {
                                legend: { display: false }
                            }
                        }
                    });
                });
            }

            // 🔹 Update data saat dropdown kota/kabupaten diubah
            $("#city").on("change", function () {
                var selectedCity = $(this).val();
                updateCarousel(selectedCity);
            });

            // 🔹 Load data pertama kali saat halaman dimuat
            updateCarousel();
        });
    </script>

    <script>
    document.addEventListener("DOMContentLoaded", function () {
        const filterContainer = document.querySelector(".filter-buttons-container");

        let isDown = false;
        let startX;
        let scrollLeft;

        filterContainer.addEventListener("mousedown", (e) => {
            isDown = true;
            startX = e.pageX - filterContainer.offsetLeft;
            scrollLeft = filterContainer.scrollLeft;
        });

        filterContainer.addEventListener("mouseleave", () => {
            isDown = false;
        });

        filterContainer.addEventListener("mouseup", () => {
            isDown = false;
        });

        filterContainer.addEventListener("mousemove", (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - filterContainer.offsetLeft;
            const walk = (x - startX) * 2; // Kecepatan geser
            filterContainer.scrollLeft = scrollLeft - walk;
        });

        // Event untuk touch screen
        filterContainer.addEventListener("touchstart", (e) => {
            startX = e.touches[0].pageX - filterContainer.offsetLeft;
            scrollLeft = filterContainer.scrollLeft;
        });

        filterContainer.addEventListener("touchmove", (e) => {
            const x = e.touches[0].pageX - filterContainer.offsetLeft;
            const walk = (x - startX) * 2;
            filterContainer.scrollLeft = scrollLeft - walk;
        });
    });
    </script>
    <script>
    document.addEventListener("DOMContentLoaded", function () {
        const filterButtons = document.querySelectorAll(".btn-filter");
        const priceCards = document.querySelectorAll(".price-card");

        filterButtons.forEach(button => {
            button.addEventListener("click", function () {
                // Ambil kategori yang dipilih
                const selectedCategory = this.innerText


                // Ubah tampilan tombol yang aktif
                filterButtons.forEach(btn => btn.classList.remove("active"));
                this.classList.add("active");

                // Jika "Semua" dipilih, tampilkan semua card
                if (selectedCategory === "Semua") {
                    priceCards.forEach(card => {
                        card.style.visibility = "visible";  // Menampilkan
                        card.style.opacity = "1";
                        card.style.transform = "scale(1)";
                    });
                } else {
                    // Sembunyikan semua card, lalu tampilkan yang sesuai kategori
                    priceCards.forEach(card => {

                        if (card.getAttribute("data-category") === selectedCategory) {
                            card.style.visibility = "visible";  // Menampilkan
                            card.style.opacity = "1";
                            card.style.transform = "scale(1)";
                        } else {
                            card.style.visibility = "hidden";  // Menyembunyikan
                            card.style.opacity = "0";
                            card.style.transform = "scale(1)";
                        }
                    });
                }
            });
        });
    });

    </script>


</body>

</html>