<?php
header('Content-Type: application/json');

// Aktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

function fetchData($start_date, $end_date) {
    $api_url = "https://api-sp2kp.kemendag.go.id/report/api/average-price/export-area-daily-json";

    $city_market_mapping = [
        "3528" => "453", // Pamekasan -> Pasar Kolpajung
        "3527" => "452", // Sampang -> Pasar Srimangunan
        "3529" => "42", // Sumenep -> Pasar Anom Baru
        "3526" => "451", // Bangkalan -> Pasar Ki Lemah Duwur
    ];
    
    // Ambil kode kota dari request
    $selected_city = isset($_GET['kode_kab_kota']) ? $_GET['kode_kab_kota'] : '3528'; // Default: Pamekasan
    error_log("get_data.php menerima kode kota: " . $selected_city);
    $selected_market = isset($city_market_mapping[$selected_city]) ? $city_market_mapping[$selected_city] : '453'; // Pasar sesuai kota
    
    $post_data = [
        "start_date" => $start_date,
        "end_date" => $end_date,
        "level" => 3,
        "variant_ids" => "52,51,9,10,17,18,26,27,25,19",
        "kode_provinsi" => 35,
        "kode_kab_kota" => $selected_city, // Gunakan kode kota dari dropdown
        "pasar_id" => $selected_market, // Gunakan kode pasar yang otomatis dipilih
        "skip_sat_sun" => true,
        "tipe_komoditas" => 1
    ];

    // Konversi ke format `x-www-form-urlencoded`
    $form_data = http_build_query($post_data);

    // Inisialisasi cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/x-www-form-urlencoded",
        "Accept: application/json"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $form_data);

    // Eksekusi request
    $response = curl_exec($ch);
    curl_close($ch);

    // Jika terjadi error, return null
    if ($response === false) {
        return null;
    }

    return json_decode($response, true);
}

// 🔹 Tentukan rentang 3 hari terakhir
$end_date = "2025-01-31"; 
// date("Y-m-d"); // Hari ini
$start_date = "2025-01-29";
// date("Y-m-d", strtotime("-2 days")); // 2 hari sebelum hari ini

// Debugging: Cek rentang tanggal yang digunakan
$data = fetchData($start_date, $end_date);

// Jika tidak ada data, tetap kembalikan JSON kosong
if (!$data || empty($data['data'])) {
    echo json_encode(["error" => "Tidak ada data dalam rentang waktu yang diambil"]);
    exit;
}

// 🔹 Cleaning Data: Ambil hanya variant, date, harga, dan hitung perubahan harga
$cleaned_data = [];
foreach ($data['data'] as $item) {
    $variant_name = $item['variant'];
    $dates = [];
    $prices = [];
    
    foreach ($item['daftarHarga'] as $harga) {
        $dates[] = $harga['date'];
        $prices[] = $harga['harga']; // Harga tetap ditampilkan meskipun 0
    }

    // Hitung perubahan harga
    $status = "turun"; // Default status dianggap turun
    $jumlah = 0;
    $persen = 0;

    if (count($prices) > 1) {
        $last_price = end($prices);
        $prev_price = prev($prices);

        if ($prev_price > 0) { // Hindari pembagian dengan nol
            $jumlah = abs($last_price - $prev_price);
            $persen = round(($jumlah / $prev_price) * 100, 2);
        }

        // Jika harga naik, ubah status menjadi "naik"
        if ($last_price > $prev_price) {
            $status = "naik";
        }
    }

    // Simpan data ke array
    $cleaned_data[] = [
        "variant" => $variant_name,
        "date" => $dates,
        "harga" => $prices,
        "status" => $status, // Hanya "naik" atau "turun"
        "jumlah" => $jumlah,
        "persen" => $persen . "%"
    ];
}

// Output hasil dalam format JSON
echo json_encode($cleaned_data, JSON_PRETTY_PRINT);
?>
